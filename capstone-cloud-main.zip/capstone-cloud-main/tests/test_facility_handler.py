import json
import os
import unittest

os.environ["TABLE_FACILITIES"] = "TestFacilities"
from backend.src.handlers import facility_handler




class TestFacilityHandler(unittest.TestCase):

    def test_get_facilities(self):

        facilities = [
            {"town": "CapeTown", "facility_id": "CPT001"},
            {"town": "Joburg", "facility_id": "JHB001"},
        ]

        def fake_scan(self, **kwargs):
            return {"Items": facilities}

        table = type("T", (), {"scan": fake_scan})()
        facility_handler.facilities_table = table

        event = {"queryStringParameters": None}

        resp = facility_handler.get_facilities(event, None)
        body = json.loads(resp["body"])

        self.assertEqual(resp["statusCode"], 200)
        self.assertEqual(len(body["facilities"]), 2)
        self.assertEqual(body["facilities"][0]["facility_id"], "CPT001")

    def test_get_facilities_filtered(self):

        facilities = [
            {"town": "CapeTown", "facility_id": "CPT001"},
            {"town": "Joburg", "facility_id": "JHB001"},
        ]

        def fake_query(self, **kwargs):
            return {"Items": [facilities[0]]}

        table = type("T", (), {"query": fake_query})()
        facility_handler.facilities_table = table

        event = {"queryStringParameters": {"town": "CapeTown"}}

        resp = facility_handler.get_facilities(event, None)
        body = json.loads(resp["body"])

        self.assertEqual(len(body["facilities"]), 1)
        self.assertEqual(body["facilities"][0]["town"], "CapeTown")


if __name__ == "__main__":
    unittest.main()
