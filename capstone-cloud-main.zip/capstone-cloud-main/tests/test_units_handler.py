import json
import os
import unittest

os.environ["TABLE_UNITS"] = "Units"
os.environ["TABLE_DISCOUNTS"] = "Discounts"

from backend.src.handlers import units_handler

class TestUnitsHandler(unittest.TestCase):
   
    def setUp(self):

        #Reset tables before each test

        units_handler.units_table = None
        units_handler.discounts_table = None


    def test_units_no_discount(self):
        units = [
            {
                "unit_id": "U1",
                "facility_id": "F1",
                "status": "Available",
                "price_per_day": 100,
                "price_per_month": 1000,
            }
        ]

        def fake_query(self, **kwargs):
            return {"Items": units}

        units_handler.units_table = type("T", (), {"query": fake_query})()
        units_handler.discounts_table = type("D", (), {})()  # empty table

        event = {
            "pathParameters": {"facility_id": "F1"},
            "queryStringParameters": {"status": "Available"},
        }

        resp = units_handler.get_units_by_facility(event, None)
        body = json.loads(resp["body"])

        self.assertEqual(resp["statusCode"], 200)
        self.assertEqual(body["units"][0]["unit_id"], "U1")

    def test_units_with_discount(self):
        units = [
            {
                "unit_id": "U1",
                "facility_id": "F1",
                "status": "Available",
                "price_per_day": 100,
                "price_per_month": 1000,
            }
        ]
        discounts = {"discount_code": "SUMMER10", "percentage": 10}

        def fake_query(self, **kwargs):
            return {"Items": units}

        def fake_get_item(self, Key):
            return {"Item": discounts}

        units_handler.units_table = type("T", (), {"query": fake_query})()
        units_handler.discounts_table = type("D", (), {"get_item": fake_get_item})()

        event = {
            "pathParameters": {"facility_id": "F1"},
            "queryStringParameters": {"status": "Available", "discount_code": "SUMMER10"},
        }

        resp = units_handler.get_units_by_facility(event, None)
        body = json.loads(resp["body"])

        self.assertEqual(body["units"][0]["effective_price_per_day"], 90.0)