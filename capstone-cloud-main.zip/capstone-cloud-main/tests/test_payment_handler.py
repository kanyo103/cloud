import sys
import os
import unittest
import json
import boto3
from decimal import Decimal
from unittest.mock import patch, MagicMock
from moto import mock_aws

# --- PATH SETUP ---
current_dir = os.path.dirname(os.path.abspath(__file__))
handlers_path = os.path.join(current_dir, '../backend/src/handlers')
sys.path.append(handlers_path)

# --- MOCK CREDENTIALS ---
os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
os.environ['TABLE_PAYMENTS'] = 'TestPaymentsTable'

import payment_handler

@mock_aws
class TestPaymentHandler(unittest.TestCase):

    def setUp(self):
        self.dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        self.table = self.dynamodb.create_table(
            TableName='TestPaymentsTable',
            KeySchema=[{'AttributeName': 'payment_id', 'KeyType': 'HASH'}],
            AttributeDefinitions=[{'AttributeName': 'payment_id', 'AttributeType': 'S'}],
            ProvisionedThroughput={'ReadCapacityUnits': 1, 'WriteCapacityUnits': 1}
        )
        payment_handler.payments_table = self.table

    @patch('payment_handler.get_user_id')
    @patch('payment_handler.build_response')
    def test_process_payment_success(self, mock_build_res, mock_get_user_id):
        # Setup Mocks
        mock_get_user_id.return_value = 'test-user-123'
        mock_build_res.side_effect = lambda status, body: {'statusCode': status, 'body': body}
        
        mock_context = MagicMock()
        mock_context.aws_request_id = 'req-123'

        event = {
            'body': json.dumps({
                'booking_id': 'booking-99',
                'amount': 150.00
            })
        }

        # Run
        response = payment_handler.process_payment(event, mock_context)

        # Assert
        self.assertEqual(response['statusCode'], 200)
        
        # Verify DB Write
        items = self.table.scan()['Items']
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['booking_id'], 'booking-99')
        self.assertEqual(items[0]['status'], 'Completed')
        self.assertEqual(items[0]['amount'], Decimal('150'))