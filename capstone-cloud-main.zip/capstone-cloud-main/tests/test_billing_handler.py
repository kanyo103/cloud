import sys
import os
import unittest
import boto3
from moto import mock_aws

# --- PATH SETUP ---
current_dir = os.path.dirname(os.path.abspath(__file__))
handlers_path = os.path.join(current_dir, '../backend/src/handlers')
sys.path.append(handlers_path)

# --- MOCK CREDENTIALS ---
os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'
os.environ['AWS_SECURITY_TOKEN'] = 'testing'
os.environ['AWS_SESSION_TOKEN'] = 'testing'
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
os.environ['TABLE_BOOKINGS'] = 'TestBookingsTable'

# Now safe to import
import billing_handler

@mock_aws
class TestBillingHandler(unittest.TestCase):

    def setUp(self):
        self.dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        self.table = self.dynamodb.create_table(
            TableName='TestBookingsTable',
            KeySchema=[{'AttributeName': 'booking_id', 'KeyType': 'HASH'}],
            AttributeDefinitions=[{'AttributeName': 'booking_id', 'AttributeType': 'S'}],
            ProvisionedThroughput={'ReadCapacityUnits': 1, 'WriteCapacityUnits': 1}
        )
        # Force the handler to use this mocked table resource
        billing_handler.bookings_table = self.table

    def test_generate_monthly_invoices(self):
        # 1. Seed Data: One Active, One Cancelled
        self.table.put_item(Item={
            'booking_id': 'booking-1',
            'user_id': 'user-A',
            'status': 'Active'
        })
        self.table.put_item(Item={
            'booking_id': 'booking-2',
            'user_id': 'user-B',
            'status': 'Cancelled'
        })

        # 2. Run Handler
        result = billing_handler.generate_monthly_invoices({}, {})

        # 3. Assertions
        self.assertEqual(result['invoices_generated'], 1)
        self.assertEqual(result['status'], 'success')