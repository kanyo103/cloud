import sys
import os
import unittest
import json
import boto3
from unittest.mock import patch, MagicMock
from moto import mock_aws

# --- PATH SETUP ---
current_dir = os.path.dirname(os.path.abspath(__file__))
handlers_path = os.path.join(current_dir, '../backend/src/handlers')
sys.path.append(handlers_path)

# --- MOCK CREDENTIALS ---
os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
os.environ['TABLE_SHARED'] = 'TestSharedTable'
os.environ['TABLE_BOOKINGS'] = 'TestBookingsTable'

import share_access_handler

@mock_aws
class TestShareAccessHandler(unittest.TestCase):

    def setUp(self):
        self.dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        
        # Mock Tables
        self.bookings_table = self.dynamodb.create_table(
            TableName='TestBookingsTable',
            KeySchema=[{'AttributeName': 'booking_id', 'KeyType': 'HASH'}],
            AttributeDefinitions=[{'AttributeName': 'booking_id', 'AttributeType': 'S'}],
            ProvisionedThroughput={'ReadCapacityUnits': 1, 'WriteCapacityUnits': 1}
        )
        self.shared_table = self.dynamodb.create_table(
            TableName='TestSharedTable',
            KeySchema=[{'AttributeName': 'share_id', 'KeyType': 'HASH'}],
            AttributeDefinitions=[{'AttributeName': 'share_id', 'AttributeType': 'S'}],
            ProvisionedThroughput={'ReadCapacityUnits': 1, 'WriteCapacityUnits': 1}
        )
        
        # Update handler references
        share_access_handler.bookings_table = self.bookings_table
        share_access_handler.shared_table = self.shared_table

    @patch('share_access_handler.get_user_id')
    @patch('share_access_handler.build_response')
    def test_share_access_success(self, mock_build_res, mock_get_user_id):
        # Setup
        mock_get_user_id.return_value = 'owner-123'
        mock_build_res.side_effect = lambda status, body: {'statusCode': status, 'body': body}
        
        mock_context = MagicMock()
        mock_context.aws_request_id = 'req-abc'

        # Seed booking owned by this user
        self.bookings_table.put_item(Item={
            'booking_id': 'b-1', 
            'user_id': 'owner-123'
        })

        event = {
            'pathParameters': {'booking_id': 'b-1'},
            'body': json.dumps({'email': 'friend@example.com'})
        }

        # Run
        response = share_access_handler.share_access(event, mock_context)

        # Assert
        self.assertEqual(response['statusCode'], 200)
        
        items = self.shared_table.scan()['Items']
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['guest_email'], 'friend@example.com')

    @patch('share_access_handler.get_user_id')
    @patch('share_access_handler.build_response')
    def test_share_access_forbidden(self, mock_build_res, mock_get_user_id):
        # Setup: User is NOT the owner
        mock_get_user_id.return_value = 'hacker-99'
        mock_build_res.side_effect = lambda status, body: {'statusCode': status, 'body': body}

        self.bookings_table.put_item(Item={
            'booking_id': 'b-1', 
            'user_id': 'owner-123'
        })

        event = {
            'pathParameters': {'booking_id': 'b-1'},
            'body': json.dumps({'email': 'hacker@example.com'})
        }

        # Run
        response = share_access_handler.share_access(event, MagicMock())

        # Assert
        self.assertEqual(response['statusCode'], 403)