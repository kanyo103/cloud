import json
import os
import unittest
import sys

# Add parent folder to path so 'backend' is importable
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

os.environ["TABLE_BOOKINGS"] = "Bookings"
os.environ["TABLE_UNITS"] = "Units"
os.environ["TABLE_DISCOUNTS"] = "Discounts"

from backend.src.handlers import booking_handler


class TestCreateBooking(unittest.TestCase):

    def test_create_booking(self):
        unit = {
            "unit_id": "U1",
            "facility_id": "F1",
            "status": "Available",
            "price_per_day": 100,
        }

        saved_bookings = []
        saved_updates = []

        # Fake get_item
        def fake_get_unit(Key=None):
            return {"Item": unit}

        # Fake put_item
        def fake_put_item(Item=None):
            saved_bookings.append(Item)

        # Fake update_item
        def fake_update_item(Key=None, UpdateExpression=None, ExpressionAttributeNames=None, ExpressionAttributeValues=None):
            saved_updates.append({
                "Key": Key,
                "UpdateExpression": UpdateExpression,
                "ExpressionAttributeNames": ExpressionAttributeNames,
                "ExpressionAttributeValues": ExpressionAttributeValues,
            })

        # Create fake tables
        units_handler = type("U", (), {
            "get_item": staticmethod(fake_get_unit),
            "update_item": staticmethod(fake_update_item)
        })()
        bookings_handler = type("B", (), {
            "put_item": staticmethod(fake_put_item)
        })()

        # Patch the real handler
        booking_handler.units_table = units_handler
        booking_handler.bookings_table = bookings_handler
        booking_handler.discounts_table = type("D", (), {})()

        # Test event
        event = {
            "httpMethod": "POST",
            "requestContext": {"authorizer": {"claims": {"sub": "user-1"}}},
            "body": json.dumps({
                "unit_id": "U1",
                "start_date": "2025-01-01",
                "end_date": "2025-01-03",
                "billing_option": "PREPAY",
                "payment_method": "CARD",
            }),
        }

        # Run booking
        resp = booking_handler.create_booking(event, None)
        body = json.loads(resp["body"])

        # Assertions
        self.assertEqual(resp["statusCode"], 201)
        self.assertEqual(body["booking"]["unit_id"], "U1")
        self.assertTrue(len(saved_bookings) > 0)
        self.assertTrue(len(saved_updates) > 0)
        self.assertEqual(saved_updates[0]["ExpressionAttributeValues"][":s"], "Reserved")


if __name__ == "__main__":
    unittest.main()
