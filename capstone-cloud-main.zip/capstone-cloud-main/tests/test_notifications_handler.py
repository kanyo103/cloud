import sys
import os
import unittest
import json
import boto3
from moto import mock_aws

# --- PATH SETUP ---
current_dir = os.path.dirname(os.path.abspath(__file__))
# Updated path: Only go up one level (..) to reach root, then into backend
handlers_path = os.path.join(current_dir, '../backend/src/handlers')
sys.path.append(handlers_path)

# --- MOCK CREDENTIALS ---
os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'

import notifications_handler

@mock_aws
class TestNotificationsHandler(unittest.TestCase):

    def setUp(self):
        # Setup Mock SES
        self.ses = boto3.client('ses', region_name='us-east-1')
        self.ses.verify_email_identity(EmailAddress="noreply@example.com")
        
        # Patch the client used in the handler to use our mocked client
        notifications_handler.ses = self.ses

    def test_handler_sends_email(self):
        # 1. Create Mock SQS Payload
        sqs_event = {
            'Records': [
                {
                    'body': json.dumps({
                        'unit_id': 'UNIT-101',
                        'opened_by': 'guest@example.com'
                    })
                }
            ]
        }

        # 2. Run Handler
        notifications_handler.handler(sqs_event, {})

        # 3. Verify Email Sent
        sent_quota = self.ses.get_send_quota()
        self.assertEqual(sent_quota['SentLast24Hours'], 1.0)