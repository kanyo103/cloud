# Digital Self-Storage System (Serverless Capstone)

## 📖 Project Overview
A fully serverless self-storage solution designed for the digital age. This system allows customers to browse, book, and unlock storage units via a web app without human intervention.
**Architecture:** AWS Serverless (Lambda, API Gateway, DynamoDB, Cognito).

## 📂 Repository Structure
This is a Mono-repo containing both Infrastructure-as-Code and Application Logic.

```text
├── template.yaml            # MASTER ARCHITECTURE (AWS SAM Template)
├── samconfig.toml           # SAM Deployment Configurations
├── backend/                 # Lambda Functions (Python/Java)
│   ├── src/                 # Source code for business logic
│   └── tests/               # Unit tests
├── frontend/                # Web Application (React/JS + Amplify)
├── db_scripts/              # DynamoDB seed data or utility scripts
└── README.md                # Project documentation
🚀 Getting Started
Prerequisites
AWS CLI installed and configured.

AWS SAM CLI installed.

Python 3.9+ (or your chosen runtime).

Node.js (for Frontend).

How to Run Locally (Backend)
Build the application:

Bash

sam build
Run the API locally:

Bash

sam local start-api
The API will be available at http://localhost:3000

Deployment
Deployment is handled via our GitLab CI/CD Pipeline.

Dev Branch: Deploys to the development stack.

Main Branch: Deploys to the production stack.

To deploy manually (Admins only):

Bash

sam deploy --guided
👥 Team Roles & Responsibilities
Role 1: API & Business Logic Lead

Design API endpoints (Booking, Payment, Rental Logic).

Implement AWS Lambda functions.

Postman collection for testing.

Role 2: Data Architect

Design DynamoDB tables (Users, Facilities, Units, Bookings).

Manage IAM policies and data access layers.

Role 3: Authentication & Security Engineer

Setup Cognito User Pools and App Clients.

Implement access logic for sharing units.

Role 4: Infrastructure & Deployment Engineer

Build IaC templates (SAM/CloudFormation).

Manage CI/CD pipelines and deployment scripts.

Role 5: Frontend & Integration Engineer

Build the Web App (Facility browsing, Unit reservation).

Integrate Amplify SDK for Auth and deploy to S3/CloudFront.

🔗 Project Resources
Architecture Diagram: [Link Pending]

API Documentation: [Link Pending]

Design Document: [Link Pending]