import os
import json
import boto3
from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource("dynamodb")
TABLE_FACILITIES = os.environ["TABLE_FACILITIES"]
facilities_table = dynamodb.Table(TABLE_FACILITIES)


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body, default=str),
    }


def get_facilities(event, context):
    """
    GET /facilities
    Optional query param: ?town=CapeTown
    """
    params = (event.get("queryStringParameters") or {}) or {}
    town = params.get("town")

    if town:
        
        resp = facilities_table.query(
            KeyConditionExpression=Key("town").eq(town)
        )
        items = resp.get("Items", [])
    else:
        
        resp = facilities_table.scan()
        items = resp.get("Items", [])

    return _response(200, {"facilities": items})
