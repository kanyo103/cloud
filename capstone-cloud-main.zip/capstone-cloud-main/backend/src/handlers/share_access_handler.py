import boto3
import os
import json
import uuid
from backend.src.handlers.common import build_response, get_user_id

dynamodb = boto3.resource('dynamodb')
TABLE_SHARED = os.environ.get('TABLE_SHARED')
TABLE_BOOKINGS = os.environ.get('TABLE_BOOKINGS')

shared_table = dynamodb.Table(TABLE_SHARED)
bookings_table = dynamodb.Table(TABLE_BOOKINGS)

def share_access(event, context):
    booking_id = event['pathParameters']['booking_id']
    user_id = get_user_id(event)
    
    try:
        body = json.loads(event['body'])
        guest_email = body['email']
    except (KeyError, ValueError):
        return build_response(400, {'error': 'Email is required'})

    try:
        # 1. Verify Requestor Owns Booking
        booking = bookings_table.get_item(Key={'booking_id': booking_id}).get('Item')
        if not booking:
            return build_response(404, {'error': 'Booking not found'})
        
        if booking['user_id'] != user_id:
            return build_response(403, {'error': 'Only the owner can share access'})

        # 2. Add to SharedAccessTable
        share_id = str(uuid.uuid4())
        item = {
            'share_id': share_id,
            'booking_id': booking_id,
            'guest_email': guest_email,
            'created_at': str(context.aws_request_id)
        }
        
        shared_table.put_item(Item=item)

        return build_response(200, {'message': f'Access shared with {guest_email}'})
    except Exception as e:
        print(e)
        return build_response(500, {'error': str(e)})