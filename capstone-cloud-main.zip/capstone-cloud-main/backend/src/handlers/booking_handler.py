import os
import json
import uuid
from datetime import datetime, date
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource("dynamodb")
TABLE_BOOKINGS = os.environ["TABLE_BOOKINGS"]
TABLE_UNITS = os.environ["TABLE_UNITS"]
TABLE_DISCOUNTS = os.environ.get("TABLE_DISCOUNTS")

bookings_table = dynamodb.Table(TABLE_BOOKINGS)
units_table = dynamodb.Table(TABLE_UNITS)
discounts_table = dynamodb.Table(TABLE_DISCOUNTS) if TABLE_DISCOUNTS else None

ALLOWED_BILLING = {"PREPAY", "RECURRING_MONTHLY", "RECURRING_YEARLY"}
ALLOWED_PAYMENT_METHODS = {"CARD", "EFT"}


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body, default=str),
    }


def _parse_body(event):
    body = event.get("body") or "{}"
    if event.get("isBase64Encoded"):
        import base64
        body = base64.b64decode(body).decode()
    return json.loads(body or "{}")


def _get_user(event):
    claims = (event.get("requestContext", {}).get("authorizer") or {}).get("claims") or {}
    user_id = claims.get("sub") or claims.get("cognito:username")
    email = claims.get("email")
    return user_id, email


def _parse_date(d):
    if not d:
        return None
    return datetime.strptime(d, "%Y-%m-%d").date()


def _fetch_discount(discount_code: str):
    if not discount_code or not discounts_table:
        return None
    resp = discounts_table.get_item(Key={"discount_code": discount_code})
    return resp.get("Item")


def create_booking(event, context):
    """
    POST /bookings
    Body:
    {
      "unit_id": "...",
      "start_date": "2025-01-01",
      "end_date": "2025-01-10",   // optional for recurring
      "billing_option": "PREPAY" | "RECURRING_MONTHLY" | "RECURRING_YEARLY",
      "payment_method": "CARD" | "EFT",
      "discount_code": "SUMMER10" // optional
    }
    """
    user_id, user_email = _get_user(event)
    if not user_id:
        return _response(401, {"message": "Unauthorised"})

    data = _parse_body(event)
    unit_id = data.get("unit_id")
    billing_option = data.get("billing_option")
    payment_method = data.get("payment_method")
    discount_code = data.get("discount_code")
    start_date_str = data.get("start_date")
    end_date_str = data.get("end_date")

    if not unit_id or not start_date_str or not billing_option or not payment_method:
        return _response(400, {"message": "unit_id, start_date, billing_option, payment_method are required"})

    if billing_option not in ALLOWED_BILLING:
        return _response(400, {"message": f"Invalid billing_option. Allowed: {ALLOWED_BILLING}"})

    if payment_method not in ALLOWED_PAYMENT_METHODS:
        return _response(400, {"message": f"Invalid payment_method. Allowed: {ALLOWED_PAYMENT_METHODS}"})

    start_date = _parse_date(start_date_str)
    end_date = _parse_date(end_date_str) if end_date_str else None

    
    u = units_table.get_item(Key={"unit_id": unit_id}).get("Item")
    if not u:
        return _response(404, {"message": "Unit not found"})

    if u.get("status") != "Available":
        return _response(409, {"message": "Unit not available"})

    facility_id = u.get("facility_id")
    price_per_day = float(u.get("price_per_day", 0))
    price_per_month = float(u.get("price_per_month", 0))

    
    if billing_option == "PREPAY":
        if not end_date:
            return _response(400, {"message": "end_date required for PREPAY"})
        days = (end_date - start_date).days or 1
        base_amount = price_per_day * days
        notice_period_days = 1 if days < 30 else 7
    elif billing_option == "RECURRING_MONTHLY":
        base_amount = price_per_month
        notice_period_days = 30
    else:  
        base_amount = price_per_month * 12
        notice_period_days = 60

    
    discount = _fetch_discount(discount_code)
    discount_amount = 0
    final_amount = base_amount
    if discount:
        pct = float(discount.get("percentage", 0))
        discount_amount = round(base_amount * pct / 100, 2)
        final_amount = round(base_amount - discount_amount, 2)

    now_iso = datetime.utcnow().isoformat()
    booking_id = str(uuid.uuid4())

    booking_item = {
        "booking_id": booking_id,
        "user_id": user_id,
        "user_email": user_email,
        "unit_id": unit_id,
        "facility_id": facility_id,
        "status": "Reserved",
        "billing_option": billing_option,
        "payment_method": payment_method,
        "start_date": start_date_str,
        "end_date": end_date_str,
        "notice_period_days": notice_period_days,
        "base_amount": base_amount,
        "discount_code": discount_code,
        "discount_amount": discount_amount,
        "amount_due": final_amount,
        "created_at": now_iso,
    }

    bookings_table.put_item(Item=booking_item)

    
    units_table.update_item(
        Key={"unit_id": unit_id},
        UpdateExpression="SET #s = :s",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":s": "Reserved"},
    )

    return _response(201, {"booking": booking_item})


def cancel_booking(event, context):
    """
    POST /bookings/{booking_id}/cancel
    simple rules:
    - mark booking as 'Cancelling'
    - mark unit as 'Cancelling'
    """
    user_id, _ = _get_user(event)
    if not user_id:
        return _response(401, {"message": "Unauthorised"})

    path_params = event.get("pathParameters") or {}
    booking_id = path_params.get("booking_id")
    if not booking_id:
        return _response(400, {"message": "booking_id is required in path"})

    resp = bookings_table.get_item(Key={"booking_id": booking_id})
    booking = resp.get("Item")
    if not booking:
        return _response(404, {"message": "Booking not found"})

    # Only owner can cancel (basic rule)
    if booking.get("user_id") != user_id:
        return _response(403, {"message": "You cannot cancel this booking"})

    if booking.get("status") in ["Cancelled"]:
        return _response(409, {"message": "Booking already cancelled"})

    now_iso = datetime.utcnow().isoformat()

    bookings_table.update_item(
        Key={"booking_id": booking_id},
        UpdateExpression="SET #st = :st, cancellation_requested_at = :now",
        ExpressionAttributeNames={"#st": "status"},
        ExpressionAttributeValues={":st": "Cancelling", ":now": now_iso},
    )

    # Update unit
    unit_id = booking.get("unit_id")
    if unit_id:
        units_table.update_item(
            Key={"unit_id": unit_id},
            UpdateExpression="SET #s = :s",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":s": "Cancelling"},
        )

    return _response(200, {"message": "Cancellation requested", "booking_id": booking_id})
