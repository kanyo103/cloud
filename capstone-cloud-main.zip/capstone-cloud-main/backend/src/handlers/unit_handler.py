import os
import json
import boto3
from datetime import datetime
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource("dynamodb")
sqs = boto3.client("sqs")

TABLE_BOOKINGS = os.environ.get("TABLE_BOOKINGS")
TABLE_UNITS = os.environ["TABLE_UNITS"]
SQS_QUEUE_URL = os.environ.get("SQS_QUEUE_URL")

bookings_table = dynamodb.Table(TABLE_BOOKINGS) if TABLE_BOOKINGS else None
units_table = dynamodb.Table(TABLE_UNITS)

ALLOWED_STATUSES = {"Available", "Reserved", "Cancelling", "Problem", "Unavailable"}


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body, default=str),
    }


def _get_user(event):
    claims = (event.get("requestContext", {}).get("authorizer") or {}).get("claims") or {}
    user_id = claims.get("sub") or claims.get("cognito:username")
    email = claims.get("email")
    return user_id, email


def list_units_by_status(event, context):
    """
    GET /admin/units?facility_id=xxx&status=Available
    """
    params = (event.get("queryStringParameters") or {}) or {}
    facility_id = params.get("facility_id")
    status = params.get("status")

    if not facility_id or not status:
        return _response(400, {"message": "facility_id and status are required"})

    resp = units_table.query(
        IndexName="FacilityIndex",
        KeyConditionExpression=Key("facility_id").eq(facility_id)
                               & Key("status").eq(status),
    )
    units = resp.get("Items", [])
    return _response(200, {"units": units})


def update_unit_status(event, context):
    """
    PUT /admin/units/{unit_id}/status
    Body: { "status": "Unavailable" }
    """
    path_params = event.get("pathParameters") or {}
    unit_id = path_params.get("unit_id")
    if not unit_id:
        return _response(400, {"message": "unit_id required in path"})

    body = event.get("body") or "{}"
    data = json.loads(body or "{}")
    new_status = data.get("status")

    if new_status not in ALLOWED_STATUSES:
        return _response(400, {"message": f"Invalid status. Allowed: {ALLOWED_STATUSES}"})

    units_table.update_item(
        Key={"unit_id": unit_id},
        UpdateExpression="SET #s = :s",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":s": new_status},
    )

    return _response(200, {"unit_id": unit_id, "status": new_status})


def unlock_unit(event, context):
    """
    POST /units/{unit_id}/unlock
    Authorised if:
      - caller is booking owner for an active booking on this unit
      - OR has been shared access via SharedAccessTable (handled in share handler)
    Simplified: only owner check for now.
    """
    if not bookings_table:
        return _response(500, {"message": "BOOKINGS table not configured"})

    user_id, user_email = _get_user(event)
    if not user_id:
        return _response(401, {"message": "Unauthorised"})

    path_params = event.get("pathParameters") or {}
    unit_id = path_params.get("unit_id")
    if not unit_id:
        return _response(400, {"message": "unit_id required in path"})

    # find active booking(s) for this unit
    resp = bookings_table.query(
        IndexName="UnitBookingsIndex",
        KeyConditionExpression=Key("unit_id").eq(unit_id),
    )
    bookings = resp.get("Items", [])

    # active booking = Reserved or Cancelling
    active = [b for b in bookings if b.get("status") in ("Reserved", "Cancelling")]

    if not active:
        return _response(404, {"message": "No active booking for this unit"})

    # pick first active (normally there should only be one)
    booking = active[0]
    if booking.get("user_id") != user_id:
        # (You could expand this to check SharedAccess here)
        return _response(403, {"message": "You are not allowed to unlock this unit"})

    now_iso = datetime.utcnow().isoformat()

    # Record last unlock time on booking
    bookings_table.update_item(
        Key={"booking_id": booking["booking_id"]},
        UpdateExpression="SET last_unlocked_at = :ts",
        ExpressionAttributeValues={":ts": now_iso},
    )

    # Push notification to SQS so SES lambda can email customer
    if SQS_QUEUE_URL:
        msg_body = {
            "type": "UNIT_UNLOCKED",
            "booking_id": booking["booking_id"],
            "unit_id": unit_id,
            "user_email": booking.get("user_email") or user_email,
            "timestamp": now_iso,
        }
        sqs.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps(msg_body),
        )

    # Actual hardware unlock would happen via integration in real life
    return _response(200, {"message": "Unit unlock triggered", "unit_id": unit_id})
