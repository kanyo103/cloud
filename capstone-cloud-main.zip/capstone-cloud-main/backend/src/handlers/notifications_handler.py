import boto3
import json

ses = boto3.client('ses')
# Ensure you verify this email in SES Console (Sandbox mode)
SENDER_EMAIL = "noreply@example.com" 

def handler(event, context):
    for record in event['Records']:
        try:
            payload = json.loads(record['body'])
            print(f"Processing notification for: {payload}")
            
            unit_id = payload.get('unit_id')
            opened_by = payload.get('opened_by')
            
            # TODO: In real app, look up Owner Email from Booking/User ID
            # For Capstone, we mock the recipient or log it
            recipient = "owner@example.com" 
            
            subject = f"Security Alert: Unit {unit_id} Accessed"
            body_text = f"Your unit {unit_id} was unlocked by {opened_by}."

            # Send Email
            ses.send_email(
                Source=SENDER_EMAIL,
                Destination={'ToAddresses': [recipient]},
                Message={
                    'Subject': {'Data': subject},
                    'Body': {'Text': {'Data': body_text}}
                }
            )
        except Exception as e:
            print(f"Failed to process record: {e}")