import boto3
import os
import json
import uuid
from decimal import Decimal
from common import build_response, get_user_id

dynamodb = boto3.resource('dynamodb')
TABLE_PAYMENTS = os.environ.get('TABLE_PAYMENTS')
payments_table = dynamodb.Table(TABLE_PAYMENTS)

def add_payment_method(event, context):
    user_id = get_user_id(event)
    # This is a stub. In reality, you'd talk to Stripe/PayPal
    return build_response(200, {'message': 'Payment method added (mock)'})

def process_payment(event, context):
    user_id = get_user_id(event)
    try:
        body = json.loads(event['body'])
        booking_id = body['booking_id']
        amount = body['amount']
    except (KeyError, ValueError):
        return build_response(400, {'error': 'Invalid input'})

    payment_id = str(uuid.uuid4())
    
    try:
        item = {
            'payment_id': payment_id,
            'booking_id': booking_id,
            'user_id': user_id,
            # FIX: Convert float to Decimal string, then to Decimal object
            'amount': Decimal(str(amount)),
            'status': 'Completed',
            'timestamp': str(context.aws_request_id)
        }
        
        payments_table.put_item(Item=item)
        
        return build_response(200, {'message': 'Payment processed successfully', 'payment_id': payment_id})
    except Exception as e:
        print(e)
        return build_response(500, {'error': str(e)})