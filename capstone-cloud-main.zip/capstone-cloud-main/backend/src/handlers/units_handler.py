import os
import json
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource("dynamodb")
TABLE_UNITS = os.environ["TABLE_UNITS"]
TABLE_DISCOUNTS = os.environ["TABLE_DISCOUNTS"]

units_table = dynamodb.Table(TABLE_UNITS)
discounts_table = dynamodb.Table(TABLE_DISCOUNTS)


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body, default=str),
    }


def _fetch_discount(discount_code: str):
    if not discount_code:
        return None
    resp = discounts_table.get_item(Key={"discount_code": discount_code})
    return resp.get("Item")


def get_units_by_facility(event, context):
    """
    GET /facilities/{facility_id}/units
    Optional query params:
      - status=Available
      - discount_code=SUMMER10  (used only to calculate preview pricing)
    """
    path_params = event.get("pathParameters") or {}
    facility_id = path_params.get("facility_id")
    if not facility_id:
        return _response(400, {"message": "facility_id is required in path"})

    qs = (event.get("queryStringParameters") or {}) or {}
    status = qs.get("status")
    discount_code = qs.get("discount_code")

    key_expr = Key("facility_id").eq(facility_id)
    if status:
        key_expr = key_expr & Key("status").eq(status)

    resp = units_table.query(
        IndexName="FacilityIndex",
        KeyConditionExpression=key_expr,
    )
    units = resp.get("Items", [])

    discount = _fetch_discount(discount_code)
    if discount:
        # simple percent discount example:
        percentage = float(discount.get("percentage", 0))
        for u in units:
            price_day = float(u.get("price_per_day", 0))
            price_month = float(u.get("price_per_month", 0))
            u["applied_discount_code"] = discount_code
            u["discount_percentage"] = percentage
            u["effective_price_per_day"] = round(
                price_day * (1 - percentage / 100), 2
            )
            u["effective_price_per_month"] = round(
                price_month * (1 - percentage / 100), 2
            )

    return _response(200, {"units": units})
