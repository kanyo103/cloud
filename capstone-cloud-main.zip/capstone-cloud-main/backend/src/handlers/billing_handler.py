import boto3
import os
from boto3.dynamodb.conditions import Attr

dynamodb = boto3.resource('dynamodb')
TABLE_BOOKINGS = os.environ.get('TABLE_BOOKINGS')
bookings_table = dynamodb.Table(TABLE_BOOKINGS)

def generate_monthly_invoices(event, context):
    print("Starting monthly invoice generation job...")
    
    try:
        # Scan for ACTIVE bookings
        # (For production, use GSI or careful Query patterns)
        response = bookings_table.scan(
            FilterExpression=Attr('status').eq('Active')
        )
        active_bookings = response.get('Items', [])
        
        count = 0
        for booking in active_bookings:
            user_id = booking['user_id']
            # Logic to send invoice via SES or SNS would go here
            print(f"Generating invoice for Booking {booking['booking_id']} (User: {user_id})")
            count += 1
            
        print(f"Completed. Generated {count} invoices.")
        return {'status': 'success', 'invoices_generated': count}
        
    except Exception as e:
        print(f"Error in billing job: {e}")
        raise e