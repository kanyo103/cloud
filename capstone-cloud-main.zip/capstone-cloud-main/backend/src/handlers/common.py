import json
import decimal
import os

def decimal_default(obj):
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    raise TypeError

def build_response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
        },
        'body': json.dumps(body, default=decimal_default)
    }

def get_user_id(event):
    # Extracts the User ID (sub) from the Cognito Authorizer
    try:
        return event['requestContext']['authorizer']['claims']['sub']
    except (KeyError, TypeError):
        # Fallback for testing or if auth is disabled/misconfigured
        return "test-user-id"

def get_user_email(event):
    try:
        return event['requestContext']['authorizer']['claims']['email']
    except (KeyError, TypeError):
        return "unknown@example.com"